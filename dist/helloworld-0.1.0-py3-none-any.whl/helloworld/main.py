def my_first_function()->str:
   return "hellow world"

result: str = my_first_function()

print(result)